# Weather data processing module


def process_weather_data(weather_data):

    # Check whether NASA data exists
    if not weather_data:
        return None

    try:

        # Extract individual environmental parameters
        temperature = weather_data["T2M"]

        humidity = weather_data["RH2M"]

        rainfall = weather_data["PRECTOTCORR"]

        solar_radiation = weather_data["ALLSKY_SFC_SW_DWN"]

        wind_speed = weather_data["WS2M"]

        # Calculate average temperature
        avg_temperature = sum(temperature.values()) / len(temperature)

        # Calculate average humidity
        avg_humidity = sum(humidity.values()) / len(humidity)

        # Calculate total rainfall
        total_rainfall = sum(rainfall.values())

        # Calculate average solar radiation
        avg_solar_radiation = sum(solar_radiation.values()) / len(solar_radiation)

        # Calculate average wind speed
        avg_wind_speed = sum(wind_speed.values()) / len(wind_speed)

        # Organize processed weather information
        processed_data = {

            "average_temperature": round(avg_temperature, 2),

            "average_humidity": round(avg_humidity, 2),

            "total_rainfall": round(total_rainfall, 2),

            "average_solar_radiation": round(avg_solar_radiation, 2),

            "average_wind_speed": round(avg_wind_speed, 2)

        }

        return processed_data

    except (KeyError, TypeError, ValueError, ZeroDivisionError) as e:

        print("Weather Processing Error:", e)

        return None